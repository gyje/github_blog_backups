---
layout: post
title: 欢迎订阅本站点
categories: []
image: ""
date: 2016-10-21 10:21:30
pid: 20161021-102130
excerpt: ""
# image pic must be Square[正方形]
# you can override the settings in _config.yml here !!
---

## 订阅地址
本站点的RSS地址为：[jokinkuang.info/feed.xml](http://www.jokinkuang.info/feed.xml)

## QQ邮箱订阅
QQ邮箱提供的订阅接口失效了，搜了下原因，好像是因为有xss漏洞，不过可以通过以下步骤订阅：

1. 进入QQ邮箱，打开左面板里的`阅读空间`
    ![read-space][read-space]
2. 点击`添加订阅` - 输入`jokinkuang.info/feed.xml` - 点击`订阅`
    ![feed-query][feed-query]
3. 确认`订阅`
    ![feed-add][feed-add]

[read-space]: {{ site.images_url }}qq/read-space.jpg
[feed-query]: {{ site.images_url }}qq/feed-query.jpg
[feed-add]: {{ site.images_url }}qq/feed-add.jpg
