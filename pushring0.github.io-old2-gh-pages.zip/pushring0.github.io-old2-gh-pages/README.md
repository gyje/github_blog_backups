# 我的博客

---

这是一个jekyll主题，[作者在这](https://github.com/jokinkuang/stepbystep)，要想在github pages使用该主题，需要修改一些东西。我会在这里把从零到完全使用的过程详细描述，你不需要有任何基础。

-------------------

[TOC]

## Markdown简介

> Markdown 是一种轻量级标记语言，它允许人们使用易读易写的纯文本格式编写文档，然后转换成格式丰富的HTML页面。    —— [维基百科](https://zh.wikipedia.org/wiki/Markdown)

正如您在阅读的这份文档，它使用简单的符号标识不同的标题，将某些文字标记为**粗体**或者*斜体*，创建一个[链接](http://www.example.com)或一个脚注[^demo]。下面列举了几个高级功能，更多语法请[去官方文档](http://www.appinn.com/markdown/)查看帮助。 

### 代码块
``` python
@requires_authorization
def somefunc(param1='', param2=0):
    '''A docstring'''
    if param1 > param2: # interesting
        print 'Greater'
    return (param2 - param1 + 1) or None
class SomeClass:
    pass
>>> message = '''interpreter
... prompt'''
```
### LaTeX 公式

可以创建行内公式，例如 $\Gamma(n) = (n-1)!\quad\forall n\in\mathbb N$。或者块级公式：

$$	x = \dfrac{-b \pm \sqrt{b^2 - 4ac}}{2a} $$

### 表格
| Item      |    Value | Qty  |
| :-------- | --------:| :--: |
| Computer  | 1600 USD |  5   |
| Phone     |   12 USD |  12  |
| Pipe      |    1 USD | 234  |

### 流程图
```flow
st=>start: Start
e=>end
op=>operation: My Operation
cond=>condition: Yes or No?

st->op->cond
cond(yes)->e
cond(no)->op
```

以及时序图:

```sequence
Alice->Bob: Hello Bob, how are you?
Note right of Bob: Bob thinks
Bob-->Alice: I am good thanks!
```

> **提示：**想了解更多，请查看**流程图**[语法][3]以及**时序图**[语法][4]。

### 复选框

使用 `- [ ]` 和 `- [x]` 语法可以创建复选框，实现 todo-list 等功能。例如：

- [x] 已完成事项
- [ ] 待办事项1
- [ ] 待办事项2

> **注意：复选框在github中有自己的语法
[^demo]: 这是一个示例脚注。请查阅 [MultiMarkdown 文档](https://github.com/fletcher/MultiMarkdown/wiki/MultiMarkdown-Syntax-Guide#footnotes) 关于脚注的说明。 

## jekyll简介
> 1. [Jekyll ? 简单的博客、静态网站工具](http://jekyll.com.cn/)
> 2. [jekyll_百度百科 ](http://baike.baidu.com/link?url=6lFf1aVKXwXmF_eaPh_D2_6ZUyLigFg4ORkPQORHAM7jR1bx2-nnVuUrV6MtAxsj1D3f9Zgs90bADs9KnOwERK)      用google是政治正确?
> 3. [jekyll主题列表0](http://jekyllthemes.org/)
> 4. [jekyll主题列表1](https://jekyllthemes.io/)
> 5. [jekyll主题列表2](http://themes.jekyllrc.org/)
> 6. [jekyll主题收藏](http://yongyuan.name/blog/collect-jekyll-theme.html)
> PS:只需要看一看了解就行，或许你能发现另一个漂亮的主题呢！
## 极速上手git和github
> 1. [Git及Github极简说明](https://zhuanlan.zhihu.com/p/24960472)
> 2. [廖雪峰Git教程](www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000/001373962845513aefd77a99f4145f0a2c7a7ca057e7570000)
> PS:第一个链接是在看知乎时偶遇的，当时就是看着那篇文章在10分钟内上手的git和github，但是如果你只看第一篇是什么都不会明白的，还是建议看看第二篇廖雪峰的Git教程，了解基本的几个命令就OK。
## 开始使用
### clone project
