---
layout: post
title: 与亚敏走在石像路
category: 绘画
tags: 
keywords: 
description: 
---

![1](/public/img/days/1.jpg)

