# 我的博客

---

**这是一个jekyll主题，[作者在这](https://github.com/jokinkuang/stepbystep)，要想在github pages使用该主题，需要修改一些东西。我会在这里把从零到完全使用的过程详细描述，你不需要有任何基础。**

-------------------

## Markdown简介

> Markdown 是一种轻量级标记语言，它允许人们使用易读易写的纯文本格式编写文档，然后转换成格式丰富的HTML页面。    —— [维基百科](https://zh.wikipedia.org/wiki/Markdown)

正如您在阅读的这份文档，它使用简单的符号标识不同的标题，将某些文字标记为**粗体**或者*斜体*，这是用它创建一个[链接](http://www.example.com)。下面列举了几个高级功能，更多语法请[去官方文档](http://www.appinn.com/markdown/)查看帮助。 

### 代码块
``` python
@requires_authorization
def somefunc(param1='', param2=0):
    '''A docstring'''
    if param1 > param2: # interesting
        print 'Greater'
    return (param2 - param1 + 1) or None
class SomeClass:
    pass
>>> message = '''interpreter
... prompt'''
```
### 表格
| Item      |    Value | Qty  |
| :-------- | --------:| :--: |
| Computer  | 1600 USD |  5   |
| Phone     |   12 USD |  12  |
| Pipe      |    1 USD | 234  |

### 复选框

使用 `- [ ]` 和 `- [x]` 语法可以创建复选框，实现 todo-list 等功能。例如：

- [x] 已完成事项
- [ ] 待办事项1
- [ ] 待办事项2

> **注意：复选框在github中有自己的语法

## jekyll简介
> 1. [Jekyll • 简单的博客、静态网站工具](http://jekyll.com.cn/)
> 2. [jekyll_百度百科 ](http://baike.baidu.com/link?url=6lFf1aVKXwXmF_eaPh_D2_6ZUyLigFg4ORkPQORHAM7jR1bx2-nnVuUrV6MtAxsj1D3f9Zgs90bADs9KnOwERK)      用google是政治正确?
> 3. [jekyll主题列表0](http://jekyllthemes.org/)
> 4. [jekyll主题列表1](https://jekyllthemes.io/)
> 5. [jekyll主题列表2](http://themes.jekyllrc.org/)
> 6. [jekyll主题收藏](http://yongyuan.name/blog/collect-jekyll-theme.html)
> 
> PS:只需要看一看了解就行，或许你能发现另一个漂亮的主题呢！


## 极速上手git和github
> 1. [Git及Github极简说明](https://zhuanlan.zhihu.com/p/24960472)
> 2. [廖雪峰Git教程](www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000/001373962845513aefd77a99f4145f0a2c7a7ca057e7570000)
> 
> PS:第一个链接是在看知乎时偶遇的，当时就是看着那篇文章在10分钟内上手的git和github，但是如果你只看第一篇是什么都不会明白的，还是建议看看第二篇廖雪峰的Git教程，了解基本的几个命令就OK。


## 开始使用
### 1. clone项目并配置git
1. 本地新建文件夹，以F盘myblog文件夹为例，进入myblog，右键git bash here。键入并回车：
    git clone git@github.com:pushring0/pushring0.github.io.git
2. 等待完成输出，会发现出现了一个pushring0.github.io文件夹，进入，有一个名为"".git"的隐藏文件夹。
*如果你没有看到，说明你没有设置显示隐藏文件，这里去百度解决*
3. 删除这个名为".git"的文件夹，然后把pushring0.github.io文件夹中的所有文件**全选，剪切**
4. 进入pushring0.github.io文件夹的上一级，即，f盘myblog文件夹，**粘贴**，**删除README.md文件**，**删除pushring0.github.io文件夹**
5. 桌面-右键-git bash here，现在应该有两个git窗口了，另一个不要关闭
6. 输入: ssh-keygen –t rsa –C "邮箱地址"
连续按3-4次回车,直到界面出现"RSA 2048"字符
解释:目的是为了生成密钥,就是sshkey,为了后面的同步代码到github上
7. 进入 "C:\Users\用户名\.ssh" 文件夹
用编辑器打开"id_rsa.pub"文件,全选,复制
8. 进入Github,点击头像,点击"settings",点击"SSH and GPG keys"点击New SSH key,给sshkey起个名字填写在title框中,然后把"id_rsa.pub"文件中的内容复制到key框中,点击Add SSH key,应该会有一次密码验证,填写,确定,OK.
9. 配置用户名和邮箱:
git config –global user.name "用户名"
git config –global user.email "邮箱"


### 2. 同步代码
1. 切换到另一个git窗口
2. git init (初始化本地文件夹为git仓库)
3. git remote add origin git@github.com:github用户名/github用户名.github.io.git (和远程仓库关联)
4. git pull git@github.com:github用户名/github用户名.github.io.git (先把远程仓库文件同步到本地)
5. git add .
6. git commit -m "描述文字"
7. git push origin master


### 3. 访问
浏览器访问：github用户名.github.io


### 4. 修改配置

