---
layout: post
title: 黄豆焖猪手
category: 厨房
tags: 
keywords: 
description: 
---

###材料

1. 黄豆300g
2. 猪手2个
3. 大葱3段
4. 蒜4瓣
5. 冰糖3坨

###步骤

我忘记了，回家咨询老妈后补上


###完成

历时4小时的菜哦，这回做的是江浙口味，下次可以尝试重庆的火辣猪手，应该更好吃。

![1](/public/img/food/pigtrotter.jpg)

