---
layout: post
title: 致友人书
category: 生活
tags: 年终总结
keywords: 
description: 
---

我不是个热闹的人，也不冷寂。不太习惯复杂的场面，渐渐少了矫情的漂亮话。须臾凝视时空和生活，让我产生永恒的珍惜。我很高兴能来到这里，经历这一切，认识许多朋友。也庆幸没能和所有的人都成为朋友。我尝试过许多新鲜的东西，并学会了割舍与放弃。我不再厌恶坏情绪，真实地对待每一天，没有空洞的拥抱，和虚假的眼泪。我有很多难忘的瞬间，仍然记得许多对话，常常会想起那些看过的美丽风光。我愿意用自己的眼睛去看世界，我愿意付出爱如同收获它。我开始相信，也愿你们相信：即将发生的永远是最美好的！
    OK, 写完！

	
下面的话出自一部我很喜欢的电影《返老还童》，我会经常看看这些文字，希望和你们共勉。 :)

>####For what it's worth, it's never too late, or in my case, too early, to be whoever you want to be.


>####There's no time limit, stop whenever you want.


>####You can change or stay the same.


>####There's no rules to this thing.


>####We can make the best or the worst of it.


>####I hope you make the best of it.


>####I hope you see things that startle you.


>####I hope you feel things you never felt before.


>####I hope you meet people with a different point of view.


>####I hope you live a life you're proud of.


>####If you find that you are not, I hope you have the strength to start all over again.
 


