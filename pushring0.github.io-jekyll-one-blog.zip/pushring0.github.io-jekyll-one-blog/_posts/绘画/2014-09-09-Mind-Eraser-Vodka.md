---
layout: post
title: 坐在露天酒吧
category: 绘画
tags: 
keywords: 
description: 
---

![4](/public/img/days/4_1.jpg)

